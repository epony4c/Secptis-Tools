#!/usr/bin/env python
# coding=utf-8

from async_proxy_pool.scheduler import run_schedule


run_schedule()
